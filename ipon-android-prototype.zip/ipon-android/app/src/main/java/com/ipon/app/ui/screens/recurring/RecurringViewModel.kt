package com.ipon.app.ui.screens.recurring

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ipon.app.data.local.RecurrenceFrequency
import com.ipon.app.data.local.TransactionType
import com.ipon.app.data.model.RecurringTemplate
import com.ipon.app.data.model.TransactionCategory
import com.ipon.app.data.repository.RecurringTemplateRepository
import com.ipon.app.util.Money
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class RecurringUiState(
    val dueTemplates: List<RecurringTemplate> = emptyList(),
    val allTemplates: List<RecurringTemplate> = emptyList(),
    val isLoading: Boolean = true
)

class RecurringViewModel(private val repository: RecurringTemplateRepository) : ViewModel() {

    val uiState: StateFlow<RecurringUiState> = combine(
        repository.observeDue(),
        repository.observeAll()
    ) { due, all ->
        RecurringUiState(dueTemplates = due, allTemplates = all, isLoading = false)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), RecurringUiState())

    fun confirm(template: RecurringTemplate) {
        viewModelScope.launch {
            repository.confirmIntoTransaction(template)
        }
    }

    fun togglePaused(template: RecurringTemplate) {
        viewModelScope.launch {
            repository.setPaused(template, paused = !template.isPaused)
        }
    }

    fun delete(template: RecurringTemplate) {
        viewModelScope.launch {
            repository.delete(template)
        }
    }

    fun createTemplate(
        label: String,
        amount: Money,
        type: TransactionType,
        category: TransactionCategory,
        merchantRaw: String?,
        frequency: RecurrenceFrequency,
        dayOfPeriod: Int
    ) {
        viewModelScope.launch {
            repository.create(
                RecurringTemplate(
                    id = UUID.randomUUID().toString(),
                    label = label,
                    amount = amount,
                    type = type,
                    category = category,
                    merchantRaw = merchantRaw,
                    frequency = frequency,
                    dayOfPeriod = dayOfPeriod,
                    lastConfirmedPeriodKey = null,
                    isPaused = false
                )
            )
        }
    }
}
