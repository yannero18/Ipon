package com.ipon.app.util

import com.ipon.app.data.local.TransactionType
import com.ipon.app.data.model.ExpenseCategory
import com.ipon.app.data.model.IncomeCategory
import com.ipon.app.data.model.TransactionCategory

/**
 * Classifies a raw merchant/source string (e.g. "STAMARIA-TODA-04",
 * "PERA PADALA - GCASH", "SWELDO MAY") into a [TransactionCategory].
 *
 * HONEST SCOPE NOTE: Section 3 of the proposal describes this as a small
 * on-device foundation model. That requires a labeled dataset of real PH
 * receipt/SMS merchant strings, which does not exist yet. Building or
 * fine-tuning a model without that data would just be guessing.
 *
 * What's implemented here instead is a transparent, deterministic
 * keyword-rule classifier covering common Philippine expense AND income
 * patterns: jeepney/tricycle/Grab fares, sari-sari stores, utility billers
 * (Meralco, Maynilad, PLDT, Globe), padala/remittance senders (Palawan
 * Express, Cebuana, LBC, GCash/Maya transfers), OFW remittance receipts,
 * sweldo/payroll deposits, and small-business "tindahan" income. Rules are
 * scoped per [TransactionType] so an expense string can never accidentally
 * match an income category and vice versa.
 *
 * This is meant to be replaced by an actual trained classifier later -- the
 * [MerchantClassifier] interface is the seam where that swap happens, so the
 * rest of the app (repository, UI) does not need to change when a real
 * model lands.
 */
interface MerchantClassifier {
    fun classify(rawMerchantString: String, type: TransactionType): TransactionCategory?
}

class KeywordRuleMerchantClassifier : MerchantClassifier {

    private val expenseRules: List<Pair<Regex, ExpenseCategory>> = listOf(
        Regex("toda|tricycle|jeep|grab(?!food)|angkas|joyride|lrt|mrt|\\bbus\\b|taxi|padyak|habal", RegexOption.IGNORE_CASE) to ExpenseCategory.TRANSPO,
        Regex("jollibee|mcdo|mang inasal|karenderia|restaurant|cafe|kfc|chowking|grabfood|foodpanda|carinderia|turo-?turo", RegexOption.IGNORE_CASE) to ExpenseCategory.FOOD,
        Regex("meralco|maynilad|pldt|globe(?! gcash)|smart|converge|water bill|electric bill|prepaid load", RegexOption.IGNORE_CASE) to ExpenseCategory.BILLS,
        Regex("sari-?sari|sm market|puregold|robinsons supermarket|grocery|supermarket|palengke|talipapa", RegexOption.IGNORE_CASE) to ExpenseCategory.GROCERIES,
        Regex("shopee|lazada|sm mall|uniqlo|\\bmall\\b|tiangge", RegexOption.IGNORE_CASE) to ExpenseCategory.SHOPPING,
        Regex("mercury|watsons|rose pharmacy|hospital|clinic|botika|drug store", RegexOption.IGNORE_CASE) to ExpenseCategory.HEALTH,
        Regex("netflix|spotify|cinema|sm cinema|ktv|videoke", RegexOption.IGNORE_CASE) to ExpenseCategory.ENTERTAINMENT,
        Regex("tuition|school fee|matriculation|enrollment|book ?store", RegexOption.IGNORE_CASE) to ExpenseCategory.EDUCATION,
        Regex("\\butang\\b|5-?6|loan payment|paid back", RegexOption.IGNORE_CASE) to ExpenseCategory.UTANG,
        Regex("palawan express|cebuana|lbc padala|padala sent|remit(tance)? (sent|to)", RegexOption.IGNORE_CASE) to ExpenseCategory.PADALA
    )

    private val incomeRules: List<Pair<Regex, IncomeCategory>> = listOf(
        Regex("payroll|salary|sweldo|13th month|payslip", RegexOption.IGNORE_CASE) to IncomeCategory.SALARY,
        Regex("freelance|sideline|upwork|fiverr|project payment|gig", RegexOption.IGNORE_CASE) to IncomeCategory.FREELANCE,
        Regex("ofw|remit(tance)? (received|from)|padala (received|from)|western union|wise transfer in", RegexOption.IGNORE_CASE) to IncomeCategory.REMITTANCE,
        Regex("tindahan|sari-?sari sales|online sell(ing)?|negosyo|store income", RegexOption.IGNORE_CASE) to IncomeCategory.BUSINESS,
        Regex("\\bgift\\b|abuloy|allowance|baon|aginaldo", RegexOption.IGNORE_CASE) to IncomeCategory.GIFT
    )

    override fun classify(rawMerchantString: String, type: TransactionType): TransactionCategory? {
        val normalized = rawMerchantString.trim()
        if (normalized.isEmpty()) return null

        return when (type) {
            TransactionType.EXPENSE ->
                expenseRules.firstOrNull { (pattern, _) -> pattern.containsMatchIn(normalized) }?.second
            TransactionType.INCOME ->
                incomeRules.firstOrNull { (pattern, _) -> pattern.containsMatchIn(normalized) }?.second
        }
    }
}
