package com.ipon.app.ui.screens.addtransaction

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ipon.app.data.local.TransactionType
import com.ipon.app.data.model.ExpenseCategory
import com.ipon.app.data.model.IncomeCategory
import com.ipon.app.data.model.Transaction
import com.ipon.app.data.model.TransactionCategory
import com.ipon.app.data.repository.TransactionRepository
import com.ipon.app.util.Money
import com.ipon.app.util.MerchantClassifier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class AddTransactionUiState(
    val amountInput: String = "",
    val type: TransactionType = TransactionType.EXPENSE,
    val selectedCategory: TransactionCategory? = null,
    val merchantRaw: String = "",
    val note: String = "",
    val suggestedCategory: TransactionCategory? = null,
    val amountError: String? = null,
    val savedTransactionId: String? = null
)

class AddTransactionViewModel(
    private val repository: TransactionRepository,
    private val merchantClassifier: MerchantClassifier
) : ViewModel() {

    private val _uiState = MutableStateFlow(AddTransactionUiState())
    val uiState: StateFlow<AddTransactionUiState> = _uiState.asStateFlow()

    fun onAmountChanged(value: String) {
        _uiState.update { it.copy(amountInput = value, amountError = null) }
    }

    fun onTypeChanged(type: TransactionType) {
        // Expense and income use entirely separate category enums (see
        // Category.kt), so a category chosen under one type is meaningless
        // under the other -- clear it rather than carry over a mismatched
        // selection, and re-run classification against the new type since
        // the same merchant string can mean different things depending on
        // direction (e.g. "GCash" alone is ambiguous; the type disambiguates).
        val resuggested = merchantClassifier.classify(_uiState.value.merchantRaw, type)
        _uiState.update {
            it.copy(
                type = type,
                selectedCategory = resuggested,
                suggestedCategory = resuggested
            )
        }
    }

    fun onMerchantChanged(value: String) {
        // Section 3: live, on-device classification as the merchant string is
        // typed, scoped to the currently selected transaction type so an
        // expense string can never match an income category or vice versa.
        // See KeywordRuleMerchantClassifier's header comment for this
        // prototype's honest scope versus the trained model in the proposal.
        val suggestion = merchantClassifier.classify(value, _uiState.value.type)
        _uiState.update {
            it.copy(
                merchantRaw = value,
                suggestedCategory = suggestion,
                selectedCategory = it.selectedCategory ?: suggestion
            )
        }
    }

    fun onCategorySelected(category: TransactionCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun onNoteChanged(value: String) {
        _uiState.update { it.copy(note = value) }
    }

    fun save() {
        val state = _uiState.value
        val amount = Money.parse(state.amountInput)
        if (amount == null || amount.isZero) {
            _uiState.update { it.copy(amountError = "Enter a valid amount") }
            return
        }

        val category = state.selectedCategory ?: defaultOtherFor(state.type)
        val wasAutoCategorized = state.suggestedCategory != null && state.selectedCategory == state.suggestedCategory

        val transaction = Transaction(
            id = UUID.randomUUID().toString(),
            amount = amount,
            type = state.type,
            category = category.displayName,
            merchantRaw = state.merchantRaw.ifBlank { null },
            note = state.note.ifBlank { null },
            occurredAtEpochMillis = System.currentTimeMillis(),
            isAutoCategorized = wasAutoCategorized
        )

        viewModelScope.launch {
            repository.add(transaction)
            _uiState.update { it.copy(savedTransactionId = transaction.id) }
        }
    }

    private fun defaultOtherFor(type: TransactionType): TransactionCategory = when (type) {
        TransactionType.EXPENSE -> ExpenseCategory.OTHER
        TransactionType.INCOME -> IncomeCategory.OTHER
    }
}
