package com.ipon.app.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ipon.app.BuildConfig
import com.ipon.app.di.IponViewModelFactory
import com.ipon.app.ui.theme.IponShapes
import com.ipon.app.ui.theme.KapeBrown
import com.ipon.app.ui.theme.KapeBrownSoft
import com.ipon.app.ui.theme.RicePaper
import com.ipon.app.ui.theme.Terracotta

@Composable
fun SettingsScreen(viewModelFactory: IponViewModelFactory) {
    val viewModel: SettingsViewModel = viewModel(factory = viewModelFactory)
    val dataCleared by viewModel.dataCleared.collectAsState()

    var showConfirmDialog by remember { mutableStateOf(false) }
    var showFinalConfirmDialog by remember { mutableStateOf(false) }

    LaunchedEffect(dataCleared) {
        if (dataCleared) {
            showConfirmDialog = false
            showFinalConfirmDialog = false
        }
    }

    Scaffold(containerColor = RicePaper) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            item {
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                SettingsSection(title = "About") {
                    InfoRow(label = "Version", value = BuildConfig.VERSION_NAME)
                    InfoRow(label = "Build", value = BuildConfig.VERSION_CODE.toString())
                }

                SettingsSection(title = "Your privacy") {
                    Text(
                        text = "Ipon has no login, no account, and no cloud sync. " +
                            "Everything you log lives only in this app's local database " +
                            "on this device. This app does not request internet access " +
                            "at all -- it is not just unused, it is not in the app's " +
                            "permissions.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = KapeBrownSoft
                    )
                    Text(
                        text = "Because of that, there's no cloud backup: if you " +
                            "uninstall the app, lose this device, or clear data below, " +
                            "your ledger is gone for good. That trade is the whole point " +
                            "of the privacy model, not an oversight -- but it's worth " +
                            "knowing plainly.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = KapeBrownSoft,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }

                SettingsSection(title = "Data") {
                    Text(
                        text = "Permanently erases every transaction, envelope, recurring " +
                            "template, goal, contribution, and reflection on this device. " +
                            "This cannot be undone.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = KapeBrownSoft,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    OutlinedButton(
                        onClick = { showConfirmDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Clear all data", color = Terracotta)
                    }
                }
            }
        }
    }

    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = { Text("Clear all data?") },
            text = {
                Text(
                    "This deletes your entire ledger, all envelopes, recurring " +
                        "templates, goals, and reflections. There is no cloud backup " +
                        "to restore from. This cannot be undone."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmDialog = false
                    showFinalConfirmDialog = true
                }) {
                    Text("Continue", color = Terracotta)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("Cancel", color = KapeBrownSoft)
                }
            }
        )
    }

    if (showFinalConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showFinalConfirmDialog = false },
            title = { Text("Are you sure?") },
            text = { Text("This is your last chance to back out. Everything will be permanently deleted.") },
            confirmButton = {
                TextButton(onClick = { viewModel.clearAllData() }) {
                    Text("Delete everything", color = Terracotta)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFinalConfirmDialog = false }) {
                    Text("Cancel", color = KapeBrownSoft)
                }
            }
        )
    }
}

@Composable
private fun SettingsSection(
    title: String,
    content: @Composable () -> Unit
) {
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = KapeBrownSoft,
        modifier = Modifier.padding(bottom = 8.dp, top = 8.dp)
    )
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(IponShapes.SquircleLg)
            .background(Color.White)
            .padding(16.dp)
    ) {
        content()
    }
    Spacer(modifier = Modifier.height(18.dp))
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = KapeBrownSoft)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = KapeBrown)
    }
}
