package com.ipon.app.ui.screens.envelopes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ipon.app.data.model.EnvelopeProgress
import com.ipon.app.data.model.ExpenseCategory
import com.ipon.app.di.IponViewModelFactory
import com.ipon.app.ui.components.CategoryLabel
import com.ipon.app.ui.theme.IponShapes
import com.ipon.app.ui.theme.JeepneyOrange
import com.ipon.app.ui.theme.KapeBrown
import com.ipon.app.ui.theme.KapeBrownSoft
import com.ipon.app.ui.theme.OceanTeal
import com.ipon.app.ui.theme.RicePaper
import com.ipon.app.ui.theme.RicePaperDeep
import com.ipon.app.ui.theme.TabularNumberStyle
import com.ipon.app.ui.theme.Terracotta
import com.ipon.app.util.Money
import java.util.Calendar

@Composable
fun EnvelopesScreen(viewModelFactory: IponViewModelFactory) {
    val viewModel: EnvelopesViewModel = viewModel(factory = viewModelFactory)
    val uiState by viewModel.uiState.collectAsState()

    var editingCategory by remember { mutableStateOf<ExpenseCategory?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val configuredCategories = uiState.envelopes.map { it.category }.toSet()
    val unconfiguredCategories = ExpenseCategory.entries.filter { it !in configuredCategories && it != ExpenseCategory.OTHER }

    val calendar = remember { Calendar.getInstance() }
    val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)
    val daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH)

    Scaffold(containerColor = RicePaper) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            item {
                Text(
                    text = "Envelopes",
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    text = "Monthly spending caps by category",
                    style = MaterialTheme.typography.bodyMedium,
                    color = KapeBrownSoft,
                    modifier = Modifier.padding(bottom = 20.dp)
                )
            }

            if (uiState.envelopes.isEmpty() && !uiState.isLoading) {
                item {
                    Column(modifier = Modifier.padding(bottom = 16.dp)) {
                        Text(
                            text = "No envelopes set yet this month.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = KapeBrownSoft,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )
                        TextButton(onClick = { viewModel.copyForwardFromLastMonth() }) {
                            Text("Copy last month's envelopes", color = OceanTeal)
                        }
                    }
                }
            }

            items(uiState.envelopes, key = { it.category }) { envelope ->
                EnvelopeCard(
                    envelope = envelope,
                    dayOfMonth = dayOfMonth,
                    daysInMonth = daysInMonth,
                    onClick = { editingCategory = envelope.category },
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 80.dp)
                        .clip(IponShapes.SquircleSm)
                        .background(RicePaperDeep)
                        .clickable { showAddDialog = true }
                        .padding(vertical = 14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "+ Add envelope",
                        style = MaterialTheme.typography.bodyLarge,
                        color = OceanTeal
                    )
                }
            }
        }
    }

    editingCategory?.let { category ->
        val existing = uiState.envelopes.find { it.category == category }
        SetCapDialog(
            category = category,
            initialAmount = existing?.cap,
            onConfirm = { amount ->
                viewModel.setCap(category, amount)
                editingCategory = null
            },
            onRemove = if (existing != null) {
                { viewModel.removeCap(category); editingCategory = null }
            } else null,
            onDismiss = { editingCategory = null }
        )
    }

    if (showAddDialog) {
        CategoryPickerDialog(
            categories = unconfiguredCategories,
            onSelected = { category ->
                showAddDialog = false
                editingCategory = category
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun EnvelopeCard(
    envelope: EnvelopeProgress,
    dayOfMonth: Int,
    daysInMonth: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val barColor = if (envelope.isOverBudget) Terracotta else OceanTeal
    val projection = envelope.projectedAtCurrentPace(dayOfMonth, daysInMonth)
    // Only worth surfacing if the envelope isn't already over (that case
    // already shows "Over by X" below) and there's at least a few days of
    // real spending data to extrapolate from -- a pace projection from day
    // 1 or 2 of the month is too noisy to be a useful nudge.
    val showsPaceWarning = !envelope.isOverBudget && dayOfMonth >= 3 && projection > envelope.cap

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(IponShapes.SquircleLg)
            .background(Color.White)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CategoryLabel(category = envelope.category, textColor = KapeBrown)
            Text(
                text = "${envelope.spent.formatPhp()} / ${envelope.cap.formatPhp()}",
                style = MaterialTheme.typography.bodyMedium.merge(TabularNumberStyle),
                color = if (envelope.isOverBudget) Terracotta else KapeBrownSoft
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp))
                .background(RicePaperDeep)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction = envelope.fractionUsed.coerceIn(0f, 1f))
                    .height(10.dp)
                    .clip(IponShapes.SquircleSm)
                    .background(barColor)
            )
        }

        if (envelope.isOverBudget) {
            Text(
                text = "Over by ${(-envelope.remaining).formatPhp()}",
                style = MaterialTheme.typography.bodyMedium,
                color = Terracotta,
                modifier = Modifier.padding(top = 6.dp)
            )
        } else if (showsPaceWarning) {
            Text(
                text = "At this pace, projected to reach ${projection.formatPhp()} by month's end",
                style = MaterialTheme.typography.bodyMedium,
                color = Terracotta,
                modifier = Modifier.padding(top = 6.dp)
            )
        } else {
            Text(
                text = "${envelope.remaining.formatPhp()} left",
                style = MaterialTheme.typography.bodyMedium,
                color = KapeBrownSoft,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun SetCapDialog(
    category: ExpenseCategory,
    initialAmount: Money?,
    onConfirm: (Money) -> Unit,
    onRemove: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var amountInput by remember {
        mutableStateOf(
            initialAmount?.let { (it.minorUnits / 100.0).toString() } ?: ""
        )
    }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { CategoryLabel(category = category, text = "${category.displayName} cap", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column {
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it; error = null },
                    label = { Text("Monthly cap (\u20b1)") },
                    isError = error != null,
                    supportingText = error?.let { errorText -> { Text(errorText) } }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amount = Money.parse(amountInput)
                if (amount == null || amount.isZero || amount.isNegative) {
                    error = "Enter a valid amount"
                } else {
                    onConfirm(amount)
                }
            }) {
                Text("Save", color = JeepneyOrange)
            }
        },
        dismissButton = {
            Row {
                if (onRemove != null) {
                    TextButton(onClick = onRemove) {
                        Text("Remove", color = Terracotta)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = KapeBrownSoft)
                }
            }
        }
    )
}

@Composable
private fun CategoryPickerDialog(
    categories: List<ExpenseCategory>,
    onSelected: (ExpenseCategory) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Choose a category") },
        text = {
            Column {
                if (categories.isEmpty()) {
                    Text(
                        text = "Every category already has an envelope.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = KapeBrownSoft
                    )
                } else {
                    categories.forEach { category ->
                        CategoryLabel(
                            category = category,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelected(category) }
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = KapeBrownSoft) }
        }
    )
}
