# Ipon — Android Prototype

A working skeleton implementing the architecture described in the Ipon proposal: Room over SQLite with a `WITHOUT ROWID` schema, scaled-integer (centavo) money math, an editorial Compose design system, and three real screens (Ledger, Add Transaction, Insights).

## Before you open this in Android Studio

**1. Gradle wrapper jar is missing.** This environment had no network access, so `gradle/wrapper/gradle-wrapper.jar` (a binary) could not be downloaded. `gradle-wrapper.properties` is already set to Gradle 8.7. Fix this with either:

```bash
# If you have Gradle installed locally:
gradle wrapper --gradle-version 8.7

# Or just open the project in Android Studio -- it will offer to
# generate the wrapper automatically on first sync.
```

**2. No real fonts are bundled.** Section 4 of the proposal specifies Fraunces (display) and Inter (body). This prototype ships with **system font fallbacks** (`FontFamily.Serif` / `FontFamily.SansSerif` / `FontFamily.Monospace`) in `ui/theme/Type.kt`, because the actual `.ttf` files would need to be downloaded from Google Fonts, and this build environment has no network access to fetch them. The app builds and runs correctly with the fallbacks. To get the real typefaces:

1. Download Fraunces, Inter, and Roboto Mono from [fonts.google.com](https://fonts.google.com)
2. Drop the `.ttf` files into `app/src/main/res/font/`
3. Swap the three `FontFamily` values in `Type.kt` for the commented example at the bottom of that file

**3. Launcher icon is a placeholder.** A simple coin glyph on Jeepney Orange, not a final asset.

**4. First-run Room schema validation.** `IponDatabase` uses `createFromAsset("database/ipon_schema.sql")` so the `transactions` table can be declared `WITHOUT ROWID` (Room's annotations can't express that clause). `app/build.gradle.kts` also sets `exportSchema = true` via the Room Gradle plugin, which generates a schema JSON from the `@Entity` definitions on build. Room validates the asset's actual columns against that generated schema at app startup. The two are kept in manual lockstep in this repo — if you ever add/rename/remove a field on `TransactionEntity`, you must edit `ipon_schema.sql` to match in the same commit, or the app will crash on first launch with a Room schema-mismatch exception.

## What's real vs. what's a stand-in

| Component | Status |
|---|---|
| `Money` (scaled-integer, centavo-first) | Fully implemented, unit-tested (`MoneyTest.kt`) |
| Room + `WITHOUT ROWID` schema (5 tables) | Real, via bundled `assets/database/ipon_schema.sql` and `createFromAsset`, schema version 4 |
| UUIDv4 primary keys | Real |
| Banker's rounding (`HALF_EVEN`) | Real, used in `Money.scaledBy()` and the insights percentage calc |
| Tabular figures (`tnum`) | Real, via `fontFeatureSettings = "tnum"` in `Type.kt` |
| Editorial palette / organic squircles | Real, matches the proposal's exact hex values and corner radii |
| Haptic currency feedback | Real, against Android's `VibrationEffect` API (26+) |
| Spring-physics row entry animation | Real, via Compose's `spring()` with `DampingRatioMediumBouncy` |
| **Split Expense/Income categories** | Real. `ExpenseCategory` and `IncomeCategory` are separate enums implementing a shared `TransactionCategory` interface, so a "Jollibee" merchant string can never be classified as income and vice versa. `resolveCategory()` does the type-scoped lookup for display code. |
| **Merchant classifier (Section 3)** | **Honest stand-in.** Section 3 describes an on-device foundation model. That needs a labeled dataset of real PH merchant/SMS strings that doesn't exist yet. `MerchantClassifier.kt` implements a transparent keyword-rule classifier instead, scoped by transaction type, covering common PH expense AND income patterns (jeepney/toda, Meralco, Jollibee, Shopee, palengke, sweldo, OFW remittances, sari-sari/tindahan income, freelance/sideline, padala, utang, abuloy). See that file's header comment. |
| **Envelopes** | Real. Monthly budget caps per expense category, with live spend aggregates (`combine()` over stored caps + transaction totals — never a cached counter that can drift). Includes "copy last month's envelopes forward." |
| **Recurring transactions** | Real, with a deliberate design constraint: this app never silently posts a transaction on the user's behalf. A "recurring template" surfaces as a "Log it" card when due; confirming it atomically writes the transaction AND stamps the template, via `Room.withTransaction`. |
| **Savings Goals** | Real. Goals have a target and an append-only contribution log (not a cached running total), so progress is always a live `SUM()` over real entries and can't drift if a write is missed or a contribution is deleted. |
| **Daily Reflection** | Real. A compact, collapsible card embedded directly in the Ledger screen (not a separate destination to remember to visit) pairing a one-tap mood with that day's actual spend/entry count — this is what actually delivers the proposal's "anxiety-inducing chore → mindful ritual" framing, rather than a generic standalone mood tracker. One reflection per calendar day (`UNIQUE(dayKey)`), no streaks, no guilt mechanics, fully optional. |
| **Settings** | Real. Reached via a gear icon on the Ledger header (not a 6th bottom-nav tab). Shows app version (via `BuildConfig`, which required explicitly enabling `buildConfig = true` -- off by default since AGP 8.0), an honest privacy statement that matches what's actually true about the manifest (no `INTERNET` permission, no cloud), and a two-step-confirmed "clear all data" wired to Room's built-in `clearAllTables()`. |
| **Custom category icons** | Real. Emoji replaced with hand-drawn `ImageVector` icons (`IponIcons.kt`) for every expense/income category, tintable to match each category's accent color -- something emoji can't do, and something that rendered inconsistently across OEM emoji fonts (Samsung/Pixel/OnePlus all differ). Goal emoji (🏡🏖️💍 etc.) were deliberately left as emoji -- that's user-chosen personalization for a personal goal, not app branding, so the two cases aren't the same problem. |
| **Custom app icon** | Real. Replaced the placeholder square with an alkansya (coin jar) silhouette on an Ocean Teal background, echoing the brand's own "coin dropped into a jar" framing from Section 5. Uses Ocean Teal rather than Jeepney Orange for the background, since Section 4 reserves orange specifically for action triggers, not general app branding. |
| **Month-over-month spending trends** | Real. Insights now shows "Up/Down X% from last month" for your top categories, computed by calling the same `observeCategoryBreakdownBetween` query twice (this month, last month) and diffing in `TransactionRepository.observeCategoryTrends()` -- no separate trends table, so it can never drift from the real ledger. |
| **Envelope pace projection** | Real. Envelopes now warn "At this pace, projected to reach ₱X by month's end" when the current day-of-month spend rate would exceed the cap -- pure arithmetic `(spent / days elapsed) * days in month`, explicitly not framed as AI or a forecast, just an honest extrapolation. Suppressed in the first 2 days of a month (too little data to be a useful signal) and suppressed once already over budget (redundant with the existing "Over by ₱X" message). |
| Sound-on-save ("coin drop" audio) | Not implemented in this pass — flagged as a follow-up, not faked |

## A note on nav structure

The original design mockup showed 4 bottom-nav tabs (Ledger, Insights, Envelopes, Settings). Building out Recurring and Goals as full features pushed this prototype to 5 tabs (Ledger, Envelopes, Recurring, Goals, Insights) with no Settings yet. Five tabs is at Material Design's usual comfort ceiling — worth revisiting before shipping. Reasonable options: fold Recurring into the Ledger screen as a "Due" banner instead of its own tab, or add a "More" tab that holds Recurring + Goals + Settings together.


## Architecture

```
data/
  local/        Room entities (5), DAOs, database, raw WITHOUT ROWID schema SQL
  model/        Domain models decoupled from Room entities, incl. category split
  repository/   Mediates DAO <-> domain models, exposes Flow; combines stored
                caps/contributions with live ledger aggregates (never cached counters)
di/             Manual dependency container (no Hilt, kept dependency-free)
ui/
  theme/        Color, Shape, Type tokens straight from Section 4
  components/   Reusable composables (BalanceCard, TransactionRow, FAB)
  screens/      Ledger, AddTransaction, Insights, Envelopes, Recurring, Goals
                -- each with its own ViewModel
  navigation/   Single NavHost wiring all screens (5 bottom tabs + 2 modal adds)
util/
  Money.kt               Scaled-integer currency type
  MerchantClassifier.kt  Type-scoped categorization (see honesty note above)
  HapticCurrencyFeedback.kt
```

## Running tests

```bash
./gradlew test
```

`MoneyTest.kt` checks the proposal's own worked example (₱150.50 → 15050 minor units), verifies that summing ten ₱0.10 amounts is exactly ₱1.00 (the classic float-drift failure this architecture exists to avoid), and confirms `HALF_EVEN` rounding behavior.

## Explicitly out of scope for this prototype

- The on-device merchant classification model itself (needs real training data first)
- Dark mode (the proposal's palette is built for a specific light, print-lookbook feel — see the note in `Theme.kt`)
- Sound-on-save
- A real Gradle `Migration` path (currently `fallbackToDestructiveMigration()` — see the comment in `IponDatabase.kt` for why that's fine pre-launch and dangerous post-launch)
- Per-feature export (Settings only offers clear-all, not export-before-clearing — worth adding before this is anyone's only copy of their data)
